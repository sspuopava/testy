pdf.js.utils
============

PDF Utilities

[browser](http://brendandahl.github.io/pdf.js.utils/browser/) - explore the internal structure and contents of a PDF file

[maker](http://brendandahl.github.io/pdf.js.utils/maker/) - create a minimal PDF using the extracted font of another PDF 
